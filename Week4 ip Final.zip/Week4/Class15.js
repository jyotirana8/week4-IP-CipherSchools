//  Strings  (String and string)



// console.log(typeof "it,s raining!!");


// let number = "10"

// console.log(number.toUpperCase());

// let word = "raining";  // String.prototype

// let string = "String as a name" // error
// let let = "String as a name" // error

// let String = 2000;



// console.log(word.toUpperCase());


// console.log(let);
// console.log(string);
// console.log(String);


// console.log('hello and good evening'.length)
// console.log("hello".charAt(4));



// Boolean  (true = 1 , false = 0)

// console.log(typeof 1);


// console.log(typeof true);
// console.log(typeof false);

// // console.log(typeof 'five'.isNaN());   // not used
// console.log(typeof isNaN('five'));




//  Truthy Values: any value except 0 and false
// if(1){
//     console.log("Very true!!")
// }else{
//     console.log("Very wrong!!")
// }




// if('hello'){
//     console.log("Very true!!")
// }else{
//     console.log("Very wrong!!")
// }



// Falsy Values: 0 false '' NaN undefined null

// if(0){
//     console.log("Very true!!")
// }else{
//     console.log("Very wrong!!")
// }




// if(''){
//     console.log("Very true!!")
// }else{
//     console.log("Very wrong!!")
// }



// let condition = 10/'hello';  // NaN
// if(cond){
//     console.log("Very true!!")
// }else{
//     console.log("Very wrong!!")
// }

// console.log('hello'.includes('e'));



// Null Undefined

// let score;
// let result = null;

    // if(score){
    //     console.log("Very true!!")
    // }else{
    //     console.log("Very wrong!!")
    // } //very wrong

    // if(result){
    //     console.log("Very true!!")
    // }else{
    //     console.log("Very wrong!!")
    // }  // very wrong

// let score;
// let result = null;
// // let status = null;


//     if(result){
//         console.log("Very true!!")
//     }else{
//         console.log("Very wrong!!")
//     }

// console.log(typeof score);
// console.log(typeof result);