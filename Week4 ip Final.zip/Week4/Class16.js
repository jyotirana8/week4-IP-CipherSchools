// objects

let obj = { name: "Cipher" };
// console.log(obj);

// person['country'] = 'India'   //  x  x  x  Wrong

let person = {
    name: 'John',
    email: 'john@wich.com',
    age: 45,
    status: true,
    children: {
        name: 'Jay'
    },
    hobbies: ['Reading', 'Writing', true, 100, null]  //  Array
}

// let clickedName= 'age';
// let clickedName= 'name';

// let dynamicPropValue = 'age'

// console.log(person[clickedName]);   //  !=== person.clickedName
// console.log(person);

// console.log(typeof person);

// console.log(person.name);
// console.log(typeof person.name);
// console.log(person['age']);      // === person.age
// console.log(person[children]);
// console.log(person.clickedName);
// console.log(person[dynamicPropValue]);
// console.log(person.dynamicPropValue);


// person.country = 'India'; 
// console.log(person);

// console.log(person);
// console.log(year);

let year = 2020

console.log(year);
console.log(person);
person['country'] = 'India'

// console.log(person);
// console.log(person.hobbies);
// console.log(null);





/**
 * Primitive Data 
 * Number 
 * String
 * Boolean
 * Undefined 
 */

/**
 * Referene Datatype
 * Object
 * Arrays
 * Function
 */